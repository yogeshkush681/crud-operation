package com.amstech.chinkus.servlate;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.amstech.chinkus.dto.UserDTO;
import com.amstech.chinkus.service.UserService;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String firstName = "dev";
	private int requestCount;

	private UserService userService;

	// LC Step-2
	public UserServlet() {
		System.out.println("UserServlet: Object created");
		this.userService = new UserService();
	}

	// LC Step-3
	public void init(ServletConfig config) throws ServletException {
		System.out.println("UserServlet: Call Init Method");
		this.requestCount = 0;
	}

	// LC Step-4 start
//	protected void service(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		System.out.println("UserServlet: Call Service Method");
//		// request process findall, findbymobile, login
//	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("UserServlet: Call Post Method");
		String task = request.getParameter("task");
		if (task.equalsIgnoreCase("signUp")) {
			insertUserData(request, response);
		} else if (task.equalsIgnoreCase("login")) {
			findForLogin(request, response);
		} else if (task.equalsIgnoreCase("updateById")) {
			updateUserData(request, response);
		} else {
			System.err.println("No task found");
		}

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("UserServlet: Call Get Method");
		String task = request.getParameter("task");
		if (task.equalsIgnoreCase("findByMobileNo")) {
			findByMobileNumber(request, response);
		} else if (task.equalsIgnoreCase("findAll")) {
			findAll(request, response);
		} else if (task.equalsIgnoreCase("findById")) {
			findById(request, response);
		} else if (task.equalsIgnoreCase("deleteById")) {
	//		deleteUserData(request, response);
		} else {
			System.err.println("No task found");
		}

	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("UserServlet: Call Put Method");
	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("UserServlet: Call Delete Method");
	}

	protected void doHead(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doOptions(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doTrace(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
	// LC Step-4 End

	// Step-5
	public void destroy() {
		System.out.println("UserServlet: Destroy....");
	}

	// ----------------

	public ServletConfig getServletConfig() {
		return null;
	}

	public String getServletInfo() {
		return null;
	}

	public void insertUserData(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		UserDTO userDTO = new UserDTO();
		userDTO.setFirst_name(request.getParameter("firstName"));
		userDTO.setLast_name(request.getParameter("lastName"));
		userDTO.setGmail(request.getParameter("gmail"));
		userDTO.setMobile_no(request.getParameter("mobileNumber"));
		userDTO.setPassword(request.getParameter("password"));
		userDTO.setAddress(request.getParameter("Address"));
		userDTO.setCity_id(1);
		
		userDTO.setDob(new Date());
		try {
			int count = userService.insertUserData(userDTO);
			if (count > 0) {
				// success resp | send to FE
				System.out.println("User account created successfully.");
				request.setAttribute("status", "Success");
				request.setAttribute("message", "User account created successfully..");
				request.setAttribute("redirectUrl", "login.jsp");
				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
				rd.forward(request, response);

			} else {
				// failed resp | send to FE
				System.out.println("Failed to create user account.");
				request.setAttribute("status", "Error");
				request.setAttribute("message", "Failed to create user account.");
				request.setAttribute("redirectUrl", "signUp.jsp");
				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
				rd.forward(request, response);
			}

		} catch (Exception e) {
			// error resp | send to FE
			e.printStackTrace();
			System.out.println("Failed to create user account dur to: " + e.getMessage());
			request.setAttribute("status", "Error");
			request.setAttribute("message", "Failed to create user account due to: " + e.getMessage());
			request.setAttribute("redirectUrl", "signUp.jsp");
			RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
			rd.forward(request, response);
			
			
		}
	}

	public void updateUserData(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		UserDTO userDTO = new UserDTO();
		userDTO.setId(Integer.parseInt(request.getParameter("userId")));
		userDTO.setFirst_name(request.getParameter("firstName"));
		userDTO.setLast_name(request.getParameter("lastName"));
		userDTO.setGmail(request.getParameter("gmail"));
		userDTO.setMobile_no(request.getParameter("mobileNumber"));
		userDTO.setAddress(request.getParameter("address"));
		try {
				int count = userService.updateUserData(userDTO);
				if(count > 0) {
					System.out.println("User updated successfully");
					RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
					request.setAttribute("status", "Success");
					request.setAttribute("message", "User updated successfully.");
					request.setAttribute("redirectUrl", "home.jsp");
					rd.forward(request, response);

				}else {
					System.out.println("Failed to update user");
					RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
					request.setAttribute("status", "Error");
					request.setAttribute("message", "Failed to update user");
					request.setAttribute("redirectUrl", "home.jsp");
					rd.forward(request, response);

				}
		} catch (Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
			request.setAttribute("status", "Error");
			request.setAttribute("message", "Failed to update user due to : " + e.getMessage());
			request.setAttribute("redirectUrl", "home.jsp");
			rd.forward(request, response);

		}

	}

	public void findById(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		int userId = Integer.parseInt(request.getParameter("userId"));
		try {
			UserDTO userDTO = userService.findById(userId);
			if (userDTO != null) {
				System.out.println("User found successfully.");
				request.setAttribute("editUserDTO", userDTO);
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("No user found for user id: " + userId);
				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
				request.setAttribute("status", "Error");
				request.setAttribute("message", "No user found for user id: " + userId);
				request.setAttribute("redirectUrl", "home.jsp");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
			request.setAttribute("status", "Error");
			request.setAttribute("message", "No user found for user id: " + userId + " due to: " + e.getMessage());
			request.setAttribute("redirectUrl", "home.jsp");
			rd.forward(request, response);
		}
	}

	public void findByMobileNumber(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		String mobileNumber = request.getParameter("mobileNumber");
		try {
			UserDTO userDTO = userService.findByMobileNumber(mobileNumber);
			if (userDTO != null) {
				System.out.println("User found successfully.");
				request.setAttribute("userDTO", userDTO);
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("No user found for mobile number: " + mobileNumber);
				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
				request.setAttribute("status", "Error");
				request.setAttribute("message", "No user found for mobile number: " + mobileNumber);
				request.setAttribute("redirectUrl", "home.jsp");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
			request.setAttribute("status", "Error");
			request.setAttribute("message","No user found for mobile number: " + mobileNumber + " due to: " + e.getMessage());
			request.setAttribute("redirectUrl", "home.jsp");
			rd.forward(request, response);
		}
	}

	public void findForLogin(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		;
		try {
			UserDTO userDTO = userService.findForLogin(username, password);
			if (userDTO != null) {
				System.out.println("User found successfully.");
//				response.sendRedirect("home.jsp");
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				request.setAttribute("activeUserDTO", userDTO);
				// session
				rd.forward(request, response);
			} else {
				System.out.println("wrong username pass ");
				// redirect to login page
//				response.sendRedirect("login.jsp");
				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
				request.setAttribute("status", "Error");
				request.setAttribute("message", "Wrong username and password.");
				request.setAttribute("redirectUrl", "login.jsp");
				rd.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// redirect to login page
//			response.sendRedirect("login.jsp");
			RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
			request.setAttribute("status", "Error");
			request.setAttribute("message", "Failed to login due to: " + e.getMessage());
			request.setAttribute("redirectUrl", "login.jsp");
		}
	}

	public void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			List<UserDTO> userDTOList = userService.findALL();
			if (!userDTOList.isEmpty()) {
				System.out.println("User list count: " + userDTOList.size());
				request.setAttribute("userDTOList", userDTOList);
				RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			} else {
				System.out.println("User not found");
				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
				request.setAttribute("status", "Error");
				request.setAttribute("message", "No user found.");
				request.setAttribute("redirectUrl", "home.jsp");
				rd.forward(request, response);
			}

		} catch (

		Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
			request.setAttribute("status", "Error");
			request.setAttribute("message", "Failed to find all user due to: " + e.getMessage());
			request.setAttribute("redirectUrl", "home.jsp");
			rd.forward(request, response);

		}
	}

//	public void deleteUserData(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String userId = request.getParameter("userId");
//		try {
//			int count = userService.deleteUserData(Integer.parseInt(userId));
//			if (count > 0) {
//				System.out.println("User delete successfully.");
//				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
//				request.setAttribute("status", "Success");
//				request.setAttribute("message", "User delete successfully");
//				request.setAttribute("redirectUrl", "home.jsp");
//				rd.forward(request, response);
//
//			} else {
//				System.out.println("No user found for user id: " + userId);
//				RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
//				request.setAttribute("status", "Error");
//				request.setAttribute("message", "No user found for user id: " + userId);
//				request.setAttribute("redirectUrl", "home.jsp");
//				rd.forward(request, response);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		RequestDispatcher rd = request.getRequestDispatcher("message.jsp");
//		request.setAttribute("status", "Error");
//			request.setAttribute("message", "No user found for user id: " + userId + " due to: " + e.getMessage());
//			request.setAttribute("redirectUrl", "home.jsp");
//		rd.forward(request, response);
//	}
//}
}








