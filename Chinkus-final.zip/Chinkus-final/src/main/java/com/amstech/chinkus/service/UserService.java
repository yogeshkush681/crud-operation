package com.amstech.chinkus.service;

import java.sql.SQLException;
import java.util.List;

import com.amstech.chinkus.dao.UserDAO;
import com.amstech.chinkus.dto.UserDTO;

public class UserService {
	
	private UserDAO userDAO;
	
	public UserService(){
		this.userDAO = new UserDAO();
	}
	
	
	
	public int insertUserData(UserDTO userDTO) throws ClassNotFoundException, SQLException {
		// pre
		int count =userDAO.insertUserData(userDTO);
		if(count>0) {
			// post
			
			//send email
			//send sms
			//send otp
			// other process
		}
		return count;
		
	}
	
	
	public int updateUserData(UserDTO userDTO) throws ClassNotFoundException, SQLException {
		return userDAO.updateUserData(userDTO);
	}
	
	
	public int deleteUserData(int i) throws Exception {
		return userDAO.deleteUserData(i);
	}

	public UserDTO findById(int id)throws Exception {
	return	userDAO.findByID(id);
		
		
	}
	public UserDTO findByMobileNumber(String MobileNo) throws Exception {
		return userDAO.findByMobileNo(MobileNo);
		
	}
	
	public UserDTO findForLogin(String username, String password) throws ClassNotFoundException, SQLException {
	return userDAO.findForLogin(username, password);
		
	}
	
	public List<UserDTO> findALL() throws Exception {
	return	userDAO.findALL();
		
	}




}
