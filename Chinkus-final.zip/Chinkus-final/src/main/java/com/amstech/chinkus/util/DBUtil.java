package com.amstech.chinkus.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.amstech.chinkus.util.DBUtil;

public class DBUtil {
	
	private final String URL = "jdbc:mysql://localhost:3306/tinkus_1";
	private final String USERNAME = "root";
	private final String PASSWORD = "root";
	private final String DRIVER = "com.mysql.cj.jdbc.Driver";
	
	// step 1
	
	
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName(DRIVER);
	Connection connection=	DriverManager.getConnection(URL, USERNAME, PASSWORD);
	System.out.println("connection is Successfully for database....!!!");
	return connection;
		
	}
	
	// step 4 
	public  void getclose(Connection connection, PreparedStatement pstmt) throws SQLException {
		
		if(pstmt!=null)
			pstmt.close();
		if(connection !=null)
			connection.close();
		
	}
	public  void getclose(Connection connection, PreparedStatement pstmt, ResultSet rs) throws SQLException {
		if(rs != null)
			rs.close();
		if(pstmt!=null)
			pstmt.close();
		if(connection !=null)
			connection.close();
		
	}
	
	
	public static void main(String[] args) {
		DBUtil dbUtil = new DBUtil();
		try {
			dbUtil.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		
	}
		
	

}
