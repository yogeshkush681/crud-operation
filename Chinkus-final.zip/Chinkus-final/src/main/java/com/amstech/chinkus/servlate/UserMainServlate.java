 package com.amstech.chinkus.servlate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import com.amstech.chinkus.dto.UserDTO;
import com.amstech.chinkus.service.UserService;

public class UserMainServlate {

	UserService userService = new UserService();
	
	public static void main(String args[]) {
		UserMainServlate servletMain = new UserMainServlate();
		servletMain.insertUserData();
		//servletMain.updateUserData();
		//servletMain.deleteUserData();
		//servletMain.findById();
		//servletMain.findByMobilenumber();
	//	servletMain.findForLogin();
		//servletMain.findAll();
	}
	
	
	
	
	public void insertUserData() {
		UserDTO userDTO = new UserDTO();
		
		userDTO.setId(36);
//	/	userDTO.setGender("MALE");
		userDTO.setFirst_name("vishal");
		userDTO.setLast_name("dayama");
		userDTO.setCity_id(1);
		userDTO.setAddress("nalchha");
		userDTO.setMobile_no("7047517803");
		userDTO.setPassword("vishal123");
		userDTO.setGmail("vishal@123.com");
//		userDTO.setDob(new Date());
		
		
		try {
			int count=userService.insertUserData(userDTO);
			if(count>0) {
				//success request send to FE
				System.out.println("user account created.....!");
			}else {
				System.out.println("Faild to create user account....!");
				
			}		
			
		} catch (Exception e) {
			// TODO: handle exception
			// error request // send to FE
			e.printStackTrace();
			System.out.println("Faild to crerate account "+ e.getMessage());
		}
	}
	
	
	public void updateUserData() {
		UserDTO userDTO = new UserDTO();
		
		userDTO.setFirst_name("manohar");
		userDTO.setLast_name("prashad");
		userDTO.setId(18);
		

		
		try {
			int count=userService.updateUserData(userDTO);
			if(count>0) {
				System.out.println("user account update...!");
			}else {
				System.out.println("Faild to update....!");
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("faild to update"+ e.getMessage());
		}
		
 

		
	}
//	
//	public void deleteUserData() {
//		UserDTO userDTO = new UserDTO();
//		
//	userDTO.setId(1);
//	
//		
//		try {
//			int count=userService.deleteUserData(userDTO);
//			if(count>0) {
//				System.out.println("user account deleted....!");
//				
//			}else {
//				System.out.println("faild to deleted....!");
//			}
//			
//		}catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//			System.out.println("faild to deleted....!"+ e.getMessage());
//		}
//		
//		
//	}
	
	public void findById() {
		int id = 36;
		try {
			UserDTO userDTO = userService.findById(id);
			if( userDTO !=null) {
				System.out.println("user found successfully..!");
				System.out.println(userDTO.getFirst_name());
				System.out.println(userDTO.getLast_name());
//				System.out.println(userDTO.getGender());
			}else {
				System.out.println("user not found...!"+id);
			}
				
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
		
			
		}
	public void findByMobilenumber() {
		String mobileno ="9977073750";
		try {
			UserDTO userDTO = userService.findByMobileNumber(mobileno);
			
			if(userDTO != null) {
				
				System.out.println("user found done.....!");
				System.out.println(userDTO.getFirst_name());
				System.out.println(userDTO.getLast_name());
//				System.out.println(userDTO.getGender());
			}else {
				System.out.println("not found user......!");
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		
	}
	public void findForLogin() {
		String username ="yogesh12@gamil.com";
		String password = "12345687";
		try {
			UserDTO userDTO = userService.findForLogin(username,password);
			
			if(userDTO != null) {
				
				System.out.println("user found done.....!");
				System.out.println(userDTO.getFirst_name());
				System.out.println(userDTO.getLast_name());
//				System.out.println(userDTO.getGender());
				System.out.println(userDTO.getDob());
				System.out.println(userDTO.getAddress());

			}else {
				System.out.println("not found user......!");
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		
	}
	
	public void findAll() {
		try {
			List<UserDTO>userDTOList = userService.findALL();
			List<String>firstNameList = new ArrayList<String>();
			for(UserDTO userDTO: userDTOList) {
				firstNameList.add(userDTO.getFirst_name());
			}
			System.out.println(firstNameList);
			
			List<String>firstnames = userDTOList.stream().map(dto->dto.getFirst_name()).collect(Collectors.toList());
			System.out.println(firstNameList);
			System.out.println(userDTOList.isEmpty());
			if(!userDTOList.isEmpty()) {
				System.out.println("all user found....!");
				System.out.println("user count.....!"+userDTOList.size());
				
				for(UserDTO userDTO:userDTOList){
					System.out.println("first name  "+userDTO.getFirst_name());
				}
				
			}else{
					System.out.println("user not found");
				}
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}




}
