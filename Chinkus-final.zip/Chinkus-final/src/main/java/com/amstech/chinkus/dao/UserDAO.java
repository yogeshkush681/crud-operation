package com.amstech.chinkus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.amstech.chinkus.dto.UserDTO;
import com.amstech.chinkus.util.DBUtil;

public class UserDAO {

	
	private final String USER_INSERT = "insert into user (id,city_id,first_name,mobile_no,gmail,address,dob,password,last_name)value(?,?,?,?,?,?,?,?,?)"; //pstmt
	private final String USER_UPDATE = "update user set first_name=?,last_name=? where id=?";
	private final String FIND_BY_MOBILE_NUMBER = "select * from user where mobile_no =?";
	private final String FIND_BY_ID ="select * from user where id = ?";
	private final String FIND_ALL ="select * from user";
	private final String FIND_BY_EMAIL_MOBILE_NUMBER_PASSWORD ="select * from user where(gmail =? or mobile_no=?)and password =?";
	private final String DELETE_USER_BY_ID="delete from user where id=?";
	

	
	private  DBUtil dbUtil ;
	 
	public UserDAO() {
		this.dbUtil =new DBUtil();
	}
	
	public int insertUserData(UserDTO userDTO) throws ClassNotFoundException, SQLException {
		// step 1 == connection  
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			
			connection=dbUtil.getConnection();
		 
		
		// step 2 pstmt object create
		 pstmt = connection.prepareStatement(USER_INSERT);
		
		pstmt.setInt(1, userDTO.getId());
		pstmt.setInt(2, userDTO.getCity_id());
    	pstmt.setString(3,userDTO.getFirst_name());
		pstmt.setString(4, userDTO.getMobile_no());
		pstmt.setString(5, userDTO.getGmail());
		pstmt.setString(6, userDTO.getAddress());
//		pstmt.setString(7, userDTO.getGender());
		
		// util.date >> MS >> sql.date
				long dattimeInMS = userDTO.getDob().getTime();
				pstmt.setDate(7, new java.sql.Date(dattimeInMS));
				
		pstmt.setString(8, userDTO.getPassword());
		pstmt.setString(9,userDTO.getLast_name());

		//step 3 execution 
		//boolean status = pstmt.execute();
		
		return pstmt.executeUpdate();
		
		}catch (Exception e) {
			throw e;
			// TODO: handle exception
		}finally {
			dbUtil.getclose(connection, pstmt);

			
		}
		
		
		
		
	}
	
	public int updateUserData(UserDTO userDTO) throws ClassNotFoundException, SQLException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			//step 1 connection
		 connection = dbUtil.getConnection();
		
		//step 2 query object creation and data loading/set
	    pstmt = connection.prepareStatement(USER_UPDATE);
		pstmt.setString(1, userDTO.getFirst_name());
		pstmt.setString(2, userDTO.getLast_name());
		pstmt.setInt(3, userDTO.getId());
		
		
		
		//step 3 execution
//		boolean status = pstmt.execute();
		
	        return pstmt.executeUpdate();
		
		}catch (Exception e) {
			throw e;
			// TODO: handle exception
		}finally {
			dbUtil.getclose(connection, pstmt);

			
		}
		
		
		
	}
	
	public int deleteUserData(int userDTO) throws SQLException, ClassNotFoundException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
		// step 1 connection  ...!
		 connection = dbUtil.getConnection();
		
		// step 2 create object query....!
		 pstmt = connection.prepareStatement(DELETE_USER_BY_ID);
		pstmt.setInt(1, userDTO);
		
		// step3 execution .....!
		
	   return pstmt.executeUpdate();
		}catch (Exception e) {
			throw e;
			// TODO: handle exception
		}finally {
			dbUtil.getclose(connection, pstmt);
			
		}
		
	}
	
	public UserDTO findByID(int id) throws Exception {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserDTO userDTO = null;
		try {
		// step 1 connection  ...!
		 connection = dbUtil.getConnection();
		
		// step 2 create object query....!
		 pstmt = connection.prepareStatement(FIND_BY_ID);
		
		 pstmt.setInt(1, id);
	    
		 rs=pstmt.executeQuery();
		// select *  from user where id = 1;
	
		 if(rs.next()) {
			 userDTO = new UserDTO();
			 
			userDTO.setId(rs.getInt("id"));
			userDTO.setFirst_name(rs.getString("first_name"));
			userDTO.setAddress(rs.getString("Address"));
			userDTO.setCity_id(rs.getInt("city_id"));
//			userDTO.setGender(rs.getString("gender"));
			userDTO.setPassword(rs.getString("password"));
			userDTO.setLast_name(rs.getString("last_name"));
			userDTO.setMobile_no(rs.getString("mobile_no"));
			userDTO.setGmail(rs.getString("gmail"));
			if(rs.getDate("dob")!= null) {
				userDTO.setDob(new Date(rs.getDate("dob").getTime()));
				
			}
		
		}
		
		// step3 execution .....!
		
	   return userDTO;
		}catch (Exception e) {
			throw e;
		}finally {
			dbUtil.getclose(connection, pstmt,rs);
			
		}
		
	}
	
	public UserDTO findByMobileNo(String mobileNo) throws Exception {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs= null;
		UserDTO userDTO = null;
		
		try {
			connection = dbUtil.getConnection();
			pstmt=connection.prepareStatement(FIND_BY_MOBILE_NUMBER);
			pstmt.setNString(1, mobileNo);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				userDTO = new UserDTO();
				
				userDTO.setId(rs.getInt("id"));
				userDTO.setFirst_name(rs.getString("first_name"));
				userDTO.setAddress(rs.getString("Address"));
				userDTO.setCity_id(rs.getInt("city_id"));
//				userDTO.setGender(rs.getString("gender"));
				userDTO.setPassword(rs.getString("password"));
				userDTO.setLast_name(rs.getString("last_name"));
				userDTO.setMobile_no(rs.getString("mobile_no"));
				userDTO.setGmail(rs.getString("gmail"));
				if(rs.getDate("dob")!= null) {
					userDTO.setDob(new Date(rs.getDate("dob").getTime()));

				
			}
			}
			return userDTO;
		
	}catch (Exception e) {
		throw e;
	}finally {
		dbUtil.getclose(connection, pstmt, rs);
	}
		// TODO: handle exception
	}
	
	public UserDTO findForLogin(String username,String password) throws SQLException, ClassNotFoundException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserDTO  userDTO = null;
		
		try {
			connection = dbUtil.getConnection();
			pstmt = connection.prepareStatement(FIND_BY_EMAIL_MOBILE_NUMBER_PASSWORD);
			pstmt.setString(1, username);
			pstmt.setString(2, username);	
			pstmt.setString(3, password);	
			rs = pstmt.executeQuery();
			System.out.println(username);
			System.out.println(password);
			
			if(rs.next())
			{
				 userDTO = new  UserDTO();
				 
				
				userDTO.setId(rs.getInt("id"));
				userDTO.setFirst_name(rs.getString("first_name"));
				userDTO.setAddress(rs.getString("Address"));
				userDTO.setCity_id(rs.getInt("city_id"));
//				userDTO.setGender(rs.getString("gender"));
				userDTO.setPassword(rs.getString("password"));
				userDTO.setLast_name(rs.getString("last_name"));
				userDTO.setMobile_no(rs.getString("mobile_no"));
				userDTO.setGmail(rs.getString("gmail"));
				if(rs.getDate("dob")!= null) {
					userDTO.setDob(new Date(rs.getDate("dob").getTime()));
			}
		}
			return userDTO;
			
		}catch (Exception e) {
			throw e;
		}finally {
			dbUtil.getclose(connection, pstmt, rs);
		}
			// TODO: handle exception
		}
	
	public List<UserDTO> findALL() throws Exception {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<UserDTO>userDTOsList= new ArrayList<>();
		
		try {
			connection = dbUtil.getConnection();
			pstmt = connection.prepareStatement(FIND_ALL);
			rs= pstmt.executeQuery();
			 while(rs.next()) {
				  UserDTO userDTO = new UserDTO();
				  
				    userDTO.setId(rs.getInt("id"));
					userDTO.setFirst_name(rs.getString("first_name"));
					userDTO.setAddress(rs.getString("Address"));
					userDTO.setCity_id(rs.getInt("city_id"));
//					userDTO.setGender(rs.getString("gender"));
					userDTO.setPassword(rs.getString("password"));
					userDTO.setLast_name(rs.getString("last_name"));
					userDTO.setMobile_no(rs.getString("mobile_no"));
					userDTO.setGmail(rs.getString("gmail"));
					if(rs.getDate("dob")!= null) {
						userDTO.setDob(new Date(rs.getDate("dob").getTime()));
				  
			 }
					userDTOsList.add(userDTO);
		}
			 return userDTOsList;
		
	}catch (Exception e) {
		throw e;
	}finally {
		dbUtil.getclose(connection, pstmt, rs);
		
		
	}
	}
		


}
